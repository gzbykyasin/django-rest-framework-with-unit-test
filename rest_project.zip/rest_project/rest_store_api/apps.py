from django.apps import AppConfig


class RestStoreApiConfig(AppConfig):
    name = 'rest_store_api'
